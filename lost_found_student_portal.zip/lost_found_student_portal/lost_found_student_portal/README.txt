# Lost & Found — Student Portal Prototype

## Run it
1. Extract the ZIP file.
2. Open `index.html` in a modern browser.
3. Internet is only needed to load the optional Google Fonts. The layout, sample data, and SVG item illustrations are local.

## Files
- `index.html` — page structure and item-details modal
- `css/style.css` — visual design and responsive layout
- `js/script.js` — sample records, search, tabs, modal, and prototype claim button
- `images/` — replaceable sample item illustrations

## Important
This is a front-end prototype. It does not yet have login, a database, real claim submission, or admin functionality. The Request to Claim button currently displays a prototype notice.

## Adding real items
Edit the `items` array near the top of `js/script.js`. Each item has:
- `name`, `brand`, `image`
- `location`, `date`, `description`
- `status` and `archived`

The item cards are fixed-width flex items. The gallery uses `display: flex` and `flex-wrap: wrap`, so the number of cards per row changes with available space while each card keeps its width.
